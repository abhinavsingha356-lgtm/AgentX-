import React, { useState, useRef, useEffect } from "react";

const QUICK_ACTIONS = [
  { label:"✍️ Write listing", prompt:"Write a professional property listing description for a {type} in {location}. Make it compelling, highlight key features, and end with a strong call to action." },
  { label:"📧 Draft email", prompt:"Write a professional follow-up email to a potential buyer who viewed a property yesterday. Be warm, professional, and invite them for a second viewing." },
  { label:"💬 WhatsApp reply", prompt:"Write a short, friendly WhatsApp message following up with a lead who hasn't responded in 3 days. Keep it casual and under 50 words." },
  { label:"🌏 Translate to Mandarin", prompt:"Translate the following property description to Mandarin Chinese, keeping it professional and appealing to Chinese buyers:\n\n[PASTE YOUR LISTING HERE]" },
  { label:"🌏 Translate to Bahasa", prompt:"Translate the following property description to Bahasa Indonesia/Malaysia, keeping it professional:\n\n[PASTE YOUR LISTING HERE]" },
  { label:"🤝 Negotiation tips", prompt:"Give me 5 practical negotiation tactics for a real estate agent in Asia trying to close a deal where the buyer wants a 10% discount on the asking price." },
  { label:"📊 Market report", prompt:"Write a short market update report for real estate agents in Southeast Asia, covering Singapore, KL, Bangkok, and Bali. Focus on current trends and opportunities." },
  { label:"🏠 Property highlights", prompt:"List 6 compelling bullet points highlighting the key selling features of a luxury 3-bedroom condo in Orchard Road, Singapore, priced at SGD 1.85 million." },
];

const LANGUAGES = ["English","Mandarin 中文","Bahasa Indonesia","Hindi हिंदी","Thai ภาษาไทย","Tagalog","Vietnamese","Japanese"];

export default function AIAssistant() {
  const [messages, setMessages] = useState([
    { role:"assistant", content:"Hi! I'm your AgentX AI assistant. I can write property listings, draft emails, translate to any Asian language, and give you negotiation tips.\n\nTap a quick action below or type your own request." }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [lang, setLang] = useState("English");
  const [apiKey, setApiKey] = useState(localStorage.getItem("ax_api_key") || "");
  const [showKeyInput, setShowKeyInput] = useState(!localStorage.getItem("ax_api_key"));
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:"smooth" }); }, [messages]);

  const saveKey = () => {
    localStorage.setItem("ax_api_key", apiKey);
    setShowKeyInput(false);
  };

  const send = async (text) => {
    if (!text.trim()) return;
    const storedKey = localStorage.getItem("ax_api_key");
    if (!storedKey) { setShowKeyInput(true); return; }

    const userMsg = { role:"user", content: text };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages); setInput(""); setLoading(true);

    const systemPrompt = `You are AgentX AI, an expert real estate assistant specializing in Asian property markets (Singapore, Malaysia, Indonesia, Thailand, Philippines, India, Vietnam). You help real estate agents write compelling listings, draft professional emails, translate content, and provide market insights. Respond in ${lang} unless asked otherwise. Be concise, professional, and practical.`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type":"application/json", "x-api-key": storedKey, "anthropic-version":"2023-06-01", "anthropic-dangerous-direct-browser-access":"true" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1024,
          system: systemPrompt,
          messages: newMessages.map(m=>({ role:m.role, content:m.content }))
        })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      const reply = data.content?.[0]?.text || "Sorry, I couldn't generate a response.";
      setMessages(prev => [...prev, { role:"assistant", content:reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role:"assistant", content:`⚠️ Error: ${err.message}\n\nMake sure your Claude API key is correct.` }]);
    }
    setLoading(false);
  };

  const handleQuick = (prompt) => { setInput(prompt); };

  return (
    <div style={s.root}>
      <div style={s.header}>
        <div>
          <h1 style={s.h1}>🤖 AI Assistant</h1>
          <p style={s.sub}>Powered by Claude · Multilingual · Real estate expert</p>
        </div>
        <div style={s.headerRight}>
          <select value={lang} onChange={e=>setLang(e.target.value)} style={s.langSel}>
            {LANGUAGES.map(l=><option key={l}>{l}</option>)}
          </select>
          <button onClick={()=>setShowKeyInput(!showKeyInput)} style={s.keyBtn}>
            {localStorage.getItem("ax_api_key") ? "🔑 API Key ✓" : "🔑 Set API Key"}
          </button>
        </div>
      </div>

      {/* API Key setup */}
      {showKeyInput && (
        <div className="card" style={s.keyCard}>
          <div style={s.keyTitle}>🔑 Enter your Claude API Key</div>
          <div style={s.keySub}>Get yours free at <a href="https://console.anthropic.com" target="_blank" rel="noreferrer" style={{color:"#111", fontWeight:600}}>console.anthropic.com</a></div>
          <div style={{display:"flex", gap:10, marginTop:12}}>
            <input type="password" value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="sk-ant-api03-..." style={{flex:1}}/>
            <button className="btn-primary" onClick={saveKey}>Save Key</button>
          </div>
          <div style={s.keyNote}>Your key is stored locally in your browser only. Never shared.</div>
        </div>
      )}

      {/* Quick actions */}
      <div style={s.quickRow}>
        {QUICK_ACTIONS.map(q => (
          <button key={q.label} onClick={()=>handleQuick(q.prompt)} style={s.quickBtn}>{q.label}</button>
        ))}
      </div>

      {/* Chat */}
      <div className="card" style={s.chatCard}>
        <div style={s.chatArea}>
          {messages.map((m, i) => (
            <div key={i} style={{...s.bubble, ...(m.role==="user" ? s.userBubble : s.aiBubble)}}>
              {m.role==="assistant" && <div style={s.aiLabel}>✦ AgentX AI</div>}
              <div style={{whiteSpace:"pre-wrap", lineHeight:1.7}}>{m.content}</div>
            </div>
          ))}
          {loading && (
            <div style={{...s.bubble, ...s.aiBubble}}>
              <div style={s.aiLabel}>✦ AgentX AI</div>
              <div style={{color:"#aaa"}}>Generating…</div>
            </div>
          )}
          <div ref={bottomRef}/>
        </div>

        {/* Input */}
        <div style={s.inputRow}>
          <textarea
            value={input}
            onChange={e=>setInput(e.target.value)}
            onKeyDown={e=>{ if(e.key==="Enter" && !e.shiftKey){ e.preventDefault(); send(input); }}}
            placeholder="Ask anything — write a listing, draft an email, translate content…"
            rows={2}
            style={{...s.textarea, resize:"none"}}
          />
          <button onClick={()=>send(input)} disabled={loading||!input.trim()} className="btn-primary" style={s.sendBtn}>
            {loading ? "…" : "Send"}
          </button>
        </div>
        <div style={s.inputHint}>Press Enter to send · Shift+Enter for new line</div>
      </div>
    </div>
  );
}

const s = {
  root: { maxWidth:860, margin:"0 auto" },
  header: { display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:20 },
  h1: { fontSize:24, fontWeight:700, color:"#111", marginBottom:4 },
  sub: { fontSize:13, color:"#888" },
  headerRight: { display:"flex", gap:10, alignItems:"center" },
  langSel: { padding:"8px 12px", borderRadius:8, border:"1px solid #e0e0e0", fontSize:13, background:"#fff", cursor:"pointer" },
  keyBtn: { padding:"8px 14px", borderRadius:8, border:"1px solid #e0e0e0", background:"#fff", fontSize:12, fontWeight:600, color:"#555", cursor:"pointer" },
  keyCard: { padding:20, marginBottom:20 },
  keyTitle: { fontFamily:"Space Grotesk", fontSize:15, fontWeight:700, marginBottom:4 },
  keySub: { fontSize:13, color:"#888" },
  keyNote: { fontSize:11, color:"#aaa", marginTop:8 },
  quickRow: { display:"flex", flexWrap:"wrap", gap:8, marginBottom:20 },
  quickBtn: { padding:"7px 14px", borderRadius:20, border:"1px solid #e0e0e0", background:"#fff", fontSize:12, fontWeight:500, color:"#555", cursor:"pointer", transition:"all .15s", whiteSpace:"nowrap" },
  chatCard: { overflow:"hidden" },
  chatArea: { padding:20, minHeight:400, maxHeight:520, overflowY:"auto", display:"flex", flexDirection:"column", gap:16 },
  bubble: { maxWidth:"80%", padding:"12px 16px", borderRadius:14, fontSize:13 },
  aiBubble: { background:"#f5f5f7", borderBottomLeftRadius:4, alignSelf:"flex-start", border:"1px solid #e0e0e0" },
  userBubble: { background:"#111", color:"#fff", borderBottomRightRadius:4, alignSelf:"flex-end" },
  aiLabel: { fontSize:10, fontWeight:700, letterSpacing:.8, color:"#888", textTransform:"uppercase", marginBottom:6 },
  inputRow: { display:"flex", gap:10, padding:"14px 16px", borderTop:"1px solid #e0e0e0", alignItems:"flex-end" },
  textarea: { flex:1, border:"1px solid #e0e0e0", borderRadius:8, padding:"10px 12px", fontSize:13 },
  sendBtn: { padding:"10px 20px", flexShrink:0, height:"fit-content" },
  inputHint: { padding:"0 16px 10px", fontSize:11, color:"#ccc" }
};
