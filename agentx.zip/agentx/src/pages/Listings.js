import React, { useState, useEffect } from "react";
import { collection, addDoc, query, where, getDocs, orderBy, deleteDoc, doc, serverTimestamp } from "firebase/firestore";
import { db } from "../lib/firebase";

const CURRENCIES = ["SGD","MYR","IDR","THB","PHP","INR","USD","HKD"];
const TYPES = ["Condo","House","Villa","Office","Apartment","Land","Shop"];

export default function Listings({ user }) {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title:"", location:"", type:"Condo", price:"", currency:"SGD", beds:"", baths:"", sqft:"", description:"" });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const q = query(collection(db,"listings"), where("uid","==",user.uid), orderBy("createdAt","desc"));
    const snap = await getDocs(q);
    setListings(snap.docs.map(d=>({id:d.id,...d.data()})));
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault(); setSaving(true);
    await addDoc(collection(db,"listings"), { ...form, uid: user.uid, createdAt: serverTimestamp() });
    setForm({ title:"", location:"", type:"Condo", price:"", currency:"SGD", beds:"", baths:"", sqft:"", description:"" });
    setShowForm(false); setSaving(false); load();
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this listing?")) return;
    await deleteDoc(doc(db,"listings",id)); load();
  };

  return (
    <div>
      <div style={s.topRow}>
        <div>
          <h1 style={s.h1}>Listings</h1>
          <p style={s.sub}>{listings.length} active properties</p>
        </div>
        <button className="btn-primary" onClick={() => setShowForm(!showForm)}>
          {showForm ? "✕ Cancel" : "+ Add Listing"}
        </button>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="card" style={s.form}>
          <h3 style={s.formTitle}>New Listing</h3>
          <form onSubmit={save}>
            <div style={s.grid2}>
              <div style={s.field}><label style={s.label}>Property Title *</label><input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Orchard Residences" required/></div>
              <div style={s.field}><label style={s.label}>Location *</label><input value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="e.g. Singapore, District 9" required/></div>
              <div style={s.field}><label style={s.label}>Type</label>
                <select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>
                  {TYPES.map(t=><option key={t}>{t}</option>)}
                </select>
              </div>
              <div style={s.field}><label style={s.label}>Currency</label>
                <select value={form.currency} onChange={e=>setForm({...form,currency:e.target.value})}>
                  {CURRENCIES.map(c=><option key={c}>{c}</option>)}
                </select>
              </div>
              <div style={s.field}><label style={s.label}>Price *</label><input type="number" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="1850000" required/></div>
              <div style={s.field}><label style={s.label}>Bedrooms</label><input type="number" value={form.beds} onChange={e=>setForm({...form,beds:e.target.value})} placeholder="3"/></div>
              <div style={s.field}><label style={s.label}>Bathrooms</label><input type="number" value={form.baths} onChange={e=>setForm({...form,baths:e.target.value})} placeholder="2"/></div>
              <div style={s.field}><label style={s.label}>Size (sqft)</label><input type="number" value={form.sqft} onChange={e=>setForm({...form,sqft:e.target.value})} placeholder="1450"/></div>
            </div>
            <div style={s.field}><label style={s.label}>Description</label>
              <textarea rows={3} value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Describe the property…" style={{resize:"vertical"}}/>
            </div>
            <div style={{display:"flex", gap:10, marginTop:4}}>
              <button type="submit" className="btn-primary" disabled={saving}>{saving?"Saving…":"Save Listing"}</button>
              <button type="button" className="btn-secondary" onClick={()=>setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* Listings grid */}
      {loading ? <div style={s.empty}>Loading listings…</div> :
       listings.length === 0 ? (
        <div style={s.emptyState}>
          <div style={{fontSize:48, marginBottom:12}}>🏠</div>
          <div style={s.emptyTitle}>No listings yet</div>
          <div style={s.emptySub}>Click "Add Listing" to add your first property</div>
        </div>
       ) : (
        <div style={s.grid3}>
          {listings.map(l => (
            <div key={l.id} className="card" style={s.listingCard}>
              <div style={s.cardImg}>🏠</div>
              <div style={s.cardBody}>
                <div style={s.cardType}>{l.type}</div>
                <div style={s.cardTitle}>{l.title}</div>
                <div style={s.cardLoc}>📍 {l.location}</div>
                <div style={s.cardPrice}>{l.currency} {Number(l.price).toLocaleString()}</div>
                <div style={s.cardSpecs}>
                  {l.beds && <span>🛏 {l.beds}</span>}
                  {l.baths && <span>🚿 {l.baths}</span>}
                  {l.sqft && <span>📐 {l.sqft} sqft</span>}
                </div>
                {l.description && <p style={s.cardDesc}>{l.description}</p>}
                <div style={s.cardActions}>
                  <a href={`/ai?listing=${encodeURIComponent(JSON.stringify(l))}`} style={s.aiBtn}>🤖 AI Write</a>
                  <button onClick={()=>remove(l.id)} style={s.delBtn}>Delete</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const s = {
  topRow: { display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:28 },
  h1: { fontSize:24, fontWeight:700, color:"#111", marginBottom:4 },
  sub: { fontSize:13, color:"#888" },
  form: { padding:24, marginBottom:24 },
  formTitle: { fontFamily:"Space Grotesk", fontSize:16, fontWeight:700, marginBottom:20 },
  grid2: { display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:14 },
  grid3: { display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:18 },
  field: { display:"flex", flexDirection:"column", gap:6 },
  label: { fontSize:12, fontWeight:600, color:"#555" },
  listingCard: { overflow:"hidden", display:"flex", flexDirection:"column" },
  cardImg: { height:120, background:"#f5f5f7", display:"flex", alignItems:"center", justifyContent:"center", fontSize:48 },
  cardBody: { padding:16 },
  cardType: { fontSize:10, fontWeight:700, color:"#888", textTransform:"uppercase", letterSpacing:.5, marginBottom:4 },
  cardTitle: { fontFamily:"Space Grotesk", fontSize:15, fontWeight:700, color:"#111", marginBottom:4 },
  cardLoc: { fontSize:12, color:"#888", marginBottom:8 },
  cardPrice: { fontFamily:"Space Grotesk", fontSize:18, fontWeight:800, color:"#111", marginBottom:8 },
  cardSpecs: { display:"flex", gap:12, fontSize:12, color:"#555", marginBottom:10 },
  cardDesc: { fontSize:12, color:"#888", lineHeight:1.6, marginBottom:12 },
  cardActions: { display:"flex", gap:8, alignItems:"center" },
  aiBtn: { fontSize:12, fontWeight:600, background:"#111", color:"#fff", padding:"6px 12px", borderRadius:8, display:"inline-block" },
  delBtn: { fontSize:12, fontWeight:600, background:"none", border:"1px solid #e0e0e0", color:"#aaa", padding:"6px 12px", borderRadius:8 },
  empty: { color:"#aaa", padding:20 },
  emptyState: { textAlign:"center", padding:"60px 20px" },
  emptyTitle: { fontFamily:"Space Grotesk", fontSize:18, fontWeight:700, color:"#111", marginBottom:8 },
  emptySub: { fontSize:13, color:"#888" }
};
