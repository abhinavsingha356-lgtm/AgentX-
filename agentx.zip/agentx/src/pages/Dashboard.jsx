import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { collection, query, where, getDocs, orderBy, limit } from "firebase/firestore";
import { db } from "../lib/firebase";
import { useAuth } from "../lib/AuthContext";
import Layout from "../components/Layout";

export default function Dashboard() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({ listings: 0, leads: 0, commission: 0, closings: 0 });
  const [recentLeads, setRecentLeads] = useState([]);
  const [recentListings, setRecentListings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    async function load() {
      try {
        // Listings
        const lSnap = await getDocs(query(collection(db, "listings"), where("agentId", "==", user.uid)));
        // Leads
        const dSnap = await getDocs(query(collection(db, "leads"), where("agentId", "==", user.uid)));
        const leads = dSnap.docs.map(d => ({ id: d.id, ...d.data() }));
        const listings = lSnap.docs.map(d => ({ id: d.id, ...d.data() }));
        const commission = leads.filter(l => l.stage === "closing").reduce((s, l) => s + (l.value || 0) * 0.02, 0);
        setStats({
          listings: listings.length,
          leads: leads.length,
          commission: Math.round(commission),
          closings: leads.filter(l => l.stage === "closing").length
        });
        setRecentLeads(leads.slice(0, 5));
        setRecentListings(listings.slice(0, 3));
      } catch (e) { console.error(e); }
      setLoading(false);
    }
    load();
  }, [user]);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const firstName = profile?.name?.split(" ")[0] || "Agent";
  const today = new Date().toLocaleDateString("en-US", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  const s = styles;

  return (
    <Layout>
      <div style={s.page}>
        {/* Header */}
        <div style={s.header}>
          <div>
            <h1 style={s.greeting}>{greeting}, {firstName} 👋</h1>
            <p style={s.date}>{today} · {profile?.country || "Asia"}</p>
          </div>
          <button style={s.aiBtn} onClick={() => navigate("/ai")}>🤖 Ask AI</button>
        </div>

        {/* KPIs */}
        <div style={s.kpiGrid}>
          {[
            { label: "Active Listings", value: loading ? "—" : stats.listings, delta: "properties live", icon: "🏠" },
            { label: "Total Leads", value: loading ? "—" : stats.leads, delta: "in pipeline", icon: "👥" },
            { label: "Commission Est.", value: loading ? "—" : `$${stats.commission.toLocaleString()}`, delta: "from closings", icon: "💰" },
            { label: "Closing Deals", value: loading ? "—" : stats.closings, delta: "need follow-up", icon: "🤝" },
          ].map((k, i) => (
            <div key={i} style={s.kpiCard}>
              <div style={s.kpiTop}>
                <span style={s.kpiLabel}>{k.label}</span>
                <span style={s.kpiIcon}>{k.icon}</span>
              </div>
              <div style={s.kpiValue}>{k.value}</div>
              <div style={s.kpiDelta}>{k.delta}</div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div style={s.section}>
          <h3 style={s.sectionTitle}>Quick Actions</h3>
          <div style={s.quickGrid}>
            {[
              { icon: "🏠", label: "Add Listing", path: "/listings" },
              { icon: "👤", label: "Add Lead", path: "/leads" },
              { icon: "✍️", label: "Write with AI", path: "/ai" },
              { icon: "📊", label: "View Analytics", path: "/analytics" },
            ].map((a, i) => (
              <button key={i} style={s.quickBtn} onClick={() => navigate(a.path)}>
                <span style={s.quickIcon}>{a.icon}</span>
                <span style={s.quickLabel}>{a.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div style={s.twoCol}>
          {/* Recent Leads */}
          <div style={s.card}>
            <div style={s.cardHead}>
              <h3 style={s.cardTitle}>Recent Leads</h3>
              <span style={s.cardLink} onClick={() => navigate("/leads")}>View all →</span>
            </div>
            {recentLeads.length === 0 ? (
              <div style={s.empty}>
                <div style={s.emptyIcon}>👥</div>
                <p>No leads yet.</p>
                <button style={s.emptyBtn} onClick={() => navigate("/leads")}>Add your first lead</button>
              </div>
            ) : recentLeads.map(lead => (
              <div key={lead.id} style={s.leadRow}>
                <div style={s.leadAv}>{lead.name?.slice(0,2).toUpperCase()}</div>
                <div style={s.leadInfo}>
                  <div style={s.leadName}>{lead.name}</div>
                  <div style={s.leadSub}>{lead.property} · {lead.country}</div>
                </div>
                <div style={{...s.stageBadge, ...stageColors[lead.stage || "cold"]}}>{lead.stage || "cold"}</div>
              </div>
            ))}
          </div>

          {/* Recent Listings */}
          <div style={s.card}>
            <div style={s.cardHead}>
              <h3 style={s.cardTitle}>Active Listings</h3>
              <span style={s.cardLink} onClick={() => navigate("/listings")}>View all →</span>
            </div>
            {recentListings.length === 0 ? (
              <div style={s.empty}>
                <div style={s.emptyIcon}>🏠</div>
                <p>No listings yet.</p>
                <button style={s.emptyBtn} onClick={() => navigate("/listings")}>Add your first listing</button>
              </div>
            ) : recentListings.map(l => (
              <div key={l.id} style={s.listingRow}>
                <div style={s.listingIcon}>🏠</div>
                <div style={s.leadInfo}>
                  <div style={s.leadName}>{l.title}</div>
                  <div style={s.leadSub}>📍 {l.location} · {l.currency} {Number(l.price || 0).toLocaleString()}</div>
                </div>
                <div style={s.listingViews}>👁 {l.views || 0}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Market Pulse */}
        <div style={s.card}>
          <div style={s.cardHead}>
            <h3 style={s.cardTitle}>🌏 Asia Market Pulse</h3>
            <span style={s.cardLink}>Live data</span>
          </div>
          <div style={s.marketGrid}>
            {[
              { flag:"🇸🇬", city:"Singapore", growth:"+8.2%", pct:88 },
              { flag:"🇹🇭", city:"Bangkok", growth:"+6.1%", pct:72 },
              { flag:"🇮🇩", city:"Bali", growth:"+5.4%", pct:65 },
              { flag:"🇲🇾", city:"Kuala Lumpur", growth:"+4.8%", pct:58 },
              { flag:"🇵🇭", city:"Manila", growth:"+3.9%", pct:48 },
              { flag:"🇮🇳", city:"Mumbai", growth:"+3.2%", pct:42 },
            ].map((m, i) => (
              <div key={i} style={s.marketRow}>
                <span style={s.marketCity}>{m.flag} {m.city}</span>
                <div style={s.barWrap}><div style={{...s.bar, width: `${m.pct}%`}} /></div>
                <span style={s.marketVal}>{m.growth}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}

const stageColors = {
  hot:     { background: "#FFF0F0", color: "#CC2222" },
  warm:    { background: "#FFFBF0", color: "#AA7700" },
  cold:    { background: "#F5F5F5", color: "#888888" },
  closing: { background: "#F0FFF8", color: "#117744" },
};

const styles = {
  page: { padding: "28px 32px", maxWidth: 1100, margin: "0 auto" },
  header: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 28, flexWrap: "wrap", gap: 12 },
  greeting: { fontSize: 24, fontWeight: 700, color: "#111", marginBottom: 4 },
  date: { fontSize: 13, color: "#888" },
  aiBtn: {
    background: "#111", color: "#fff", border: "none",
    padding: "10px 18px", borderRadius: 10, fontSize: 13, fontWeight: 600,
    cursor: "pointer"
  },
  kpiGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14, marginBottom: 24 },
  kpiCard: {
    background: "#fff", borderRadius: 12,
    border: "1px solid #E8E8E8", padding: "18px 20px",
    boxShadow: "0 1px 4px rgba(0,0,0,0.04)"
  },
  kpiTop: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  kpiLabel: { fontSize: 11, fontWeight: 600, color: "#888", textTransform: "uppercase", letterSpacing: "0.5px" },
  kpiIcon: { fontSize: 18 },
  kpiValue: { fontFamily: "'Space Grotesk', sans-serif", fontSize: 30, fontWeight: 800, color: "#111", letterSpacing: "-1px", marginBottom: 4 },
  kpiDelta: { fontSize: 11, color: "#888" },
  section: { marginBottom: 24 },
  sectionTitle: { fontSize: 15, fontWeight: 700, color: "#111", marginBottom: 12 },
  quickGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 10 },
  quickBtn: {
    background: "#fff", border: "1.5px solid #E8E8E8", borderRadius: 12,
    padding: "16px 12px", display: "flex", flexDirection: "column",
    alignItems: "center", gap: 8, cursor: "pointer",
    transition: "all 0.15s", fontFamily: "'Inter', sans-serif"
  },
  quickIcon: { fontSize: 22 },
  quickLabel: { fontSize: 12, fontWeight: 600, color: "#333" },
  twoCol: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 16, marginBottom: 16 },
  card: {
    background: "#fff", borderRadius: 12,
    border: "1px solid #E8E8E8", overflow: "hidden",
    boxShadow: "0 1px 4px rgba(0,0,0,0.04)", marginBottom: 16
  },
  cardHead: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    padding: "16px 20px", borderBottom: "1px solid #F0F0F0"
  },
  cardTitle: { fontSize: 14, fontWeight: 700, color: "#111" },
  cardLink: { fontSize: 12, color: "#555", cursor: "pointer", fontWeight: 500 },
  leadRow: { display: "flex", alignItems: "center", gap: 12, padding: "12px 20px", borderBottom: "1px solid #F8F8F8" },
  leadAv: {
    width: 34, height: 34, borderRadius: "50%", background: "#111",
    color: "#fff", display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 12, fontWeight: 700, flexShrink: 0
  },
  leadInfo: { flex: 1, minWidth: 0 },
  leadName: { fontSize: 13, fontWeight: 600, color: "#111" },
  leadSub: { fontSize: 11, color: "#888", marginTop: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  stageBadge: { fontSize: 10, fontWeight: 700, padding: "3px 9px", borderRadius: 20, textTransform: "capitalize" },
  listingRow: { display: "flex", alignItems: "center", gap: 12, padding: "12px 20px", borderBottom: "1px solid #F8F8F8" },
  listingIcon: { width: 34, height: 34, borderRadius: 8, background: "#F5F5F5", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 },
  listingViews: { fontSize: 11, color: "#888", flexShrink: 0 },
  empty: { padding: "32px 20px", textAlign: "center", color: "#888" },
  emptyIcon: { fontSize: 32, marginBottom: 8 },
  emptyBtn: {
    marginTop: 12, background: "#111", color: "#fff",
    border: "none", padding: "8px 16px", borderRadius: 8,
    fontSize: 12, fontWeight: 600, cursor: "pointer"
  },
  marketGrid: { padding: "16px 20px", display: "flex", flexDirection: "column", gap: 12 },
  marketRow: { display: "flex", alignItems: "center", gap: 12 },
  marketCity: { fontSize: 13, fontWeight: 500, color: "#111", minWidth: 140 },
  barWrap: { flex: 1, height: 5, background: "#F0F0F0", borderRadius: 3, overflow: "hidden" },
  bar: { height: "100%", background: "#111", borderRadius: 3, transition: "width 0.5s ease" },
  marketVal: { fontSize: 12, fontWeight: 700, color: "#111", minWidth: 44, textAlign: "right" },
};
