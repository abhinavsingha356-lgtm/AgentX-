import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../lib/AuthContext";

export default function AuthPage() {
  const [mode, setMode] = useState("login"); // login | register
  const [form, setForm] = useState({ name: "", email: "", password: "", country: "Singapore" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const countries = ["Singapore","Malaysia","Indonesia","Thailand","Philippines","India","Vietnam","Hong Kong","Japan","South Korea"];

  async function handleSubmit(e) {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      if (mode === "login") {
        await login(form.email, form.password);
      } else {
        await register(form.email, form.password, form.name, form.country);
      }
      navigate("/dashboard");
    } catch (err) {
      setError(err.message.replace("Firebase: ", "").replace(/\(auth.*\)/, ""));
    }
    setLoading(false);
  }

  const s = styles;
  return (
    <div style={s.page}>
      <div style={s.card}>
        {/* Logo */}
        <div style={s.logo}>
          <div style={s.logoIcon}>AX</div>
          <span style={s.logoText}>Agent<span style={{color:"#555"}}>X</span></span>
        </div>

        <h2 style={s.title}>{mode === "login" ? "Welcome back" : "Create your account"}</h2>
        <p style={s.sub}>{mode === "login" ? "Sign in to your AgentX dashboard" : "Start your 30-day free trial"}</p>

        <form onSubmit={handleSubmit} style={s.form}>
          {mode === "register" && (
            <>
              <div style={s.field}>
                <label style={s.label}>Full Name</label>
                <input style={s.input} type="text" placeholder="James Lim" required
                  value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
              </div>
              <div style={s.field}>
                <label style={s.label}>Country</label>
                <select style={s.input} value={form.country} onChange={e => setForm({...form, country: e.target.value})}>
                  {countries.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
            </>
          )}
          <div style={s.field}>
            <label style={s.label}>Email</label>
            <input style={s.input} type="email" placeholder="agent@email.com" required
              value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
          </div>
          <div style={s.field}>
            <label style={s.label}>Password</label>
            <input style={s.input} type="password" placeholder="••••••••" required
              value={form.password} onChange={e => setForm({...form, password: e.target.value})} />
          </div>

          {error && <div style={s.error}>{error}</div>}

          <button style={{...s.btn, opacity: loading ? 0.7 : 1}} type="submit" disabled={loading}>
            {loading ? "Please wait…" : mode === "login" ? "Sign In" : "Create Account"}
          </button>
        </form>

        <p style={s.toggle}>
          {mode === "login" ? "Don't have an account? " : "Already have an account? "}
          <span style={s.link} onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}>
            {mode === "login" ? "Sign up free" : "Sign in"}
          </span>
        </p>

        <div style={s.badge}>🌏 Used by agents across 10 Asian markets</div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh", background: "#F7F7F8",
    display: "flex", alignItems: "center", justifyContent: "center",
    padding: "20px"
  },
  card: {
    background: "#fff", borderRadius: 16, padding: "40px 36px",
    width: "100%", maxWidth: 420,
    boxShadow: "0 8px 40px rgba(0,0,0,0.10)",
    border: "1px solid #E8E8E8"
  },
  logo: { display: "flex", alignItems: "center", gap: 10, marginBottom: 28 },
  logoIcon: {
    width: 38, height: 38, borderRadius: 10,
    background: "#111", color: "#fff",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 16
  },
  logoText: { fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 20, color: "#111" },
  title: { fontSize: 22, fontWeight: 700, color: "#111", marginBottom: 6 },
  sub: { fontSize: 13, color: "#888", marginBottom: 28 },
  form: { display: "flex", flexDirection: "column", gap: 16 },
  field: { display: "flex", flexDirection: "column", gap: 6 },
  label: { fontSize: 12, fontWeight: 600, color: "#444", letterSpacing: "0.3px" },
  input: {
    padding: "10px 14px", borderRadius: 8,
    border: "1.5px solid #E0E0E0", background: "#FAFAFA",
    fontSize: 14, color: "#111",
    transition: "border-color 0.15s",
    width: "100%"
  },
  error: {
    background: "#FFF2F2", border: "1px solid #FFD5D5",
    color: "#CC3333", fontSize: 13, padding: "10px 14px",
    borderRadius: 8
  },
  btn: {
    background: "#111", color: "#fff",
    padding: "12px", borderRadius: 10,
    fontSize: 14, fontWeight: 700,
    marginTop: 4, transition: "opacity 0.15s"
  },
  toggle: { marginTop: 20, fontSize: 13, color: "#888", textAlign: "center" },
  link: { color: "#111", fontWeight: 600, cursor: "pointer", textDecoration: "underline" },
  badge: {
    marginTop: 24, fontSize: 12, color: "#888",
    textAlign: "center", paddingTop: 20,
    borderTop: "1px solid #F0F0F0"
  }
};
