import React, { useEffect, useState } from "react";
import { collection, query, where, getDocs, orderBy, limit } from "firebase/firestore";
import { db } from "../lib/firebase";

export default function Dashboard({ user }) {
  const [listings, setListings] = useState([]);
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const lQ = query(collection(db,"listings"), where("uid","==",user.uid), orderBy("createdAt","desc"), limit(3));
        const ldQ = query(collection(db,"leads"), where("uid","==",user.uid), orderBy("createdAt","desc"), limit(5));
        const [lSnap, ldSnap] = await Promise.all([getDocs(lQ), getDocs(ldQ)]);
        setListings(lSnap.docs.map(d=>({id:d.id,...d.data()})));
        setLeads(ldSnap.docs.map(d=>({id:d.id,...d.data()})));
      } catch(e) { console.error(e); }
      setLoading(false);
    };
    load();
  }, [user.uid]);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const name = user.email?.split("@")[0] || "Agent";

  const kpis = [
    { label:"Active Listings", value: listings.length || "—", sub:"Your properties" },
    { label:"Hot Leads",       value: leads.filter(l=>l.status==="hot").length || "—", sub:"Need follow-up" },
    { label:"Total Leads",     value: leads.length || "—", sub:"In pipeline" },
    { label:"AI Assists",      value: "∞", sub:"Always ready" },
  ];

  const statusColor = { hot:"#111", warm:"#555", cold:"#aaa", closing:"#222" };
  const statusBg    = { hot:"#f0f0f0", warm:"#f5f5f5", cold:"#fafafa", closing:"#e8e8e8" };

  return (
    <div>
      <div style={s.header}>
        <div>
          <h1 style={s.h1}>{greeting}, {name} 👋</h1>
          <p style={s.sub}>{new Date().toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}</p>
        </div>
      </div>

      {/* KPIs */}
      <div style={s.kpiGrid}>
        {kpis.map(k => (
          <div key={k.label} className="card" style={s.kpiCard}>
            <div style={s.kpiLabel}>{k.label}</div>
            <div style={s.kpiVal}>{loading ? "…" : k.value}</div>
            <div style={s.kpiSub}>{k.sub}</div>
          </div>
        ))}
      </div>

      <div style={s.grid2}>
        {/* Recent Listings */}
        <div className="card" style={s.panel}>
          <div style={s.panelHead}>
            <div style={s.panelTitle}>Recent Listings</div>
            <a href="/listings" style={s.panelLink}>View all →</a>
          </div>
          {loading ? <div style={s.empty}>Loading…</div> :
           listings.length === 0 ? <div style={s.empty}>No listings yet. <a href="/listings" style={{color:"#111", fontWeight:600}}>Add one →</a></div> :
           listings.map(l => (
            <div key={l.id} style={s.listItem}>
              <div style={s.listIcon}>🏠</div>
              <div style={{flex:1}}>
                <div style={s.listName}>{l.title}</div>
                <div style={s.listSub}>📍 {l.location} · {l.type}</div>
              </div>
              <div style={s.listPrice}>{l.currency} {Number(l.price).toLocaleString()}</div>
            </div>
          ))}
        </div>

        {/* Recent Leads */}
        <div className="card" style={s.panel}>
          <div style={s.panelHead}>
            <div style={s.panelTitle}>Recent Leads</div>
            <a href="/leads" style={s.panelLink}>View all →</a>
          </div>
          {loading ? <div style={s.empty}>Loading…</div> :
           leads.length === 0 ? <div style={s.empty}>No leads yet. <a href="/leads" style={{color:"#111", fontWeight:600}}>Add one →</a></div> :
           leads.map(l => (
            <div key={l.id} style={s.listItem}>
              <div style={s.leadAv}>{l.name?.[0]?.toUpperCase() || "?"}</div>
              <div style={{flex:1}}>
                <div style={s.listName}>{l.name}</div>
                <div style={s.listSub}>{l.interest}</div>
              </div>
              <div style={{...s.statusTag, background: statusBg[l.status]||"#f5f5f5", color: statusColor[l.status]||"#555"}}>
                {l.status || "new"}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI CTA */}
      <div style={s.aiCta}>
        <div style={s.aiCtaLeft}>
          <div style={s.aiCtaIcon}>🤖</div>
          <div>
            <div style={s.aiCtaTitle}>AI Assistant is ready</div>
            <div style={s.aiCtaSub}>Write listings, draft emails, translate to any Asian language</div>
          </div>
        </div>
        <a href="/ai" className="btn-primary" style={{padding:"10px 20px", fontSize:13}}>Open AI →</a>
      </div>
    </div>
  );
}

const s = {
  header: { marginBottom:28 },
  h1: { fontSize:26, fontWeight:700, color:"#111", marginBottom:4 },
  sub: { fontSize:13, color:"#888" },
  kpiGrid: { display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginBottom:24 },
  kpiCard: { padding:"18px 20px" },
  kpiLabel: { fontSize:11, fontWeight:600, color:"#aaa", textTransform:"uppercase", letterSpacing:.5, marginBottom:8 },
  kpiVal: { fontFamily:"Space Grotesk", fontSize:28, fontWeight:800, color:"#111", letterSpacing:-1, marginBottom:4 },
  kpiSub: { fontSize:11, color:"#888" },
  grid2: { display:"grid", gridTemplateColumns:"1fr 1fr", gap:18, marginBottom:18 },
  panel: { padding:0, overflow:"hidden" },
  panelHead: { display:"flex", alignItems:"center", justifyContent:"space-between", padding:"16px 20px", borderBottom:"1px solid #e0e0e0" },
  panelTitle: { fontFamily:"Space Grotesk", fontWeight:700, fontSize:14 },
  panelLink: { fontSize:12, color:"#555", fontWeight:600 },
  listItem: { display:"flex", alignItems:"center", gap:12, padding:"12px 20px", borderBottom:"1px solid #f0f0f0" },
  listIcon: { fontSize:22, flexShrink:0 },
  listName: { fontSize:13, fontWeight:600, color:"#111" },
  listSub: { fontSize:11, color:"#888", marginTop:1 },
  listPrice: { fontFamily:"Space Grotesk", fontSize:13, fontWeight:700, color:"#111", flexShrink:0 },
  leadAv: { width:34, height:34, borderRadius:"50%", background:"#111", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:13, flexShrink:0 },
  statusTag: { fontSize:10, fontWeight:700, padding:"3px 9px", borderRadius:20, textTransform:"uppercase", letterSpacing:.5 },
  empty: { padding:"24px 20px", color:"#aaa", fontSize:13 },
  aiCta: { background:"#111", borderRadius:12, padding:"18px 24px", display:"flex", alignItems:"center", justifyContent:"space-between" },
  aiCtaLeft: { display:"flex", alignItems:"center", gap:14 },
  aiCtaIcon: { fontSize:28 },
  aiCtaTitle: { fontFamily:"Space Grotesk", fontWeight:700, fontSize:15, color:"#fff", marginBottom:3 },
  aiCtaSub: { fontSize:12, color:"#888" }
};
