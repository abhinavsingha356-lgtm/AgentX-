import React, { useState, useEffect } from "react";
import { collection, addDoc, query, where, getDocs, orderBy, deleteDoc, doc, updateDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../lib/firebase";

const STATUSES = ["new","hot","warm","cold","closing","won","lost"];
const COUNTRIES = ["Singapore","Malaysia","Indonesia","Thailand","Philippines","India","Vietnam","Hong Kong","China","Japan"];

export default function Leads({ user }) {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState("all");
  const [form, setForm] = useState({ name:"", email:"", phone:"", country:"Singapore", interest:"", budget:"", currency:"SGD", status:"new", notes:"" });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    const q = query(collection(db,"leads"), where("uid","==",user.uid), orderBy("createdAt","desc"));
    const snap = await getDocs(q);
    setLeads(snap.docs.map(d=>({id:d.id,...d.data()})));
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault(); setSaving(true);
    await addDoc(collection(db,"leads"), { ...form, uid: user.uid, createdAt: serverTimestamp() });
    setForm({ name:"", email:"", phone:"", country:"Singapore", interest:"", budget:"", currency:"SGD", status:"new", notes:"" });
    setShowForm(false); setSaving(false); load();
  };

  const updateStatus = async (id, status) => {
    await updateDoc(doc(db,"leads",id), { status });
    setLeads(l => l.map(x => x.id===id ? {...x,status} : x));
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this lead?")) return;
    await deleteDoc(doc(db,"leads",id)); load();
  };

  const filtered = filter==="all" ? leads : leads.filter(l=>l.status===filter);

  const statusStyle = {
    new:     { bg:"#f5f5f5", color:"#555" },
    hot:     { bg:"#111",    color:"#fff" },
    warm:    { bg:"#e8e8e8", color:"#333" },
    cold:    { bg:"#f9f9f9", color:"#aaa" },
    closing: { bg:"#222",    color:"#fff" },
    won:     { bg:"#111",    color:"#fff" },
    lost:    { bg:"#fafafa", color:"#ccc" },
  };

  return (
    <div>
      <div style={s.topRow}>
        <div>
          <h1 style={s.h1}>Leads</h1>
          <p style={s.sub}>{leads.length} total · {leads.filter(l=>l.status==="hot").length} hot</p>
        </div>
        <button className="btn-primary" onClick={() => setShowForm(!showForm)}>
          {showForm ? "✕ Cancel" : "+ Add Lead"}
        </button>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="card" style={s.form}>
          <h3 style={s.formTitle}>New Lead</h3>
          <form onSubmit={save}>
            <div style={s.grid2}>
              <div style={s.field}><label style={s.label}>Full Name *</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Wei Chen" required/></div>
              <div style={s.field}><label style={s.label}>Email</label><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="wei@example.com"/></div>
              <div style={s.field}><label style={s.label}>Phone / WhatsApp</label><input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="+65 9123 4567"/></div>
              <div style={s.field}><label style={s.label}>Country</label>
                <select value={form.country} onChange={e=>setForm({...form,country:e.target.value})}>
                  {COUNTRIES.map(c=><option key={c}>{c}</option>)}
                </select>
              </div>
              <div style={s.field}><label style={s.label}>Interested In</label><input value={form.interest} onChange={e=>setForm({...form,interest:e.target.value})} placeholder="3BR Condo, Orchard Road"/></div>
              <div style={s.field}><label style={s.label}>Budget</label><input value={form.budget} onChange={e=>setForm({...form,budget:e.target.value})} placeholder="1,500,000"/></div>
              <div style={s.field}><label style={s.label}>Status</label>
                <select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}>
                  {STATUSES.map(s=><option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div style={s.field}><label style={s.label}>Notes</label>
              <textarea rows={2} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} placeholder="Any notes about this lead…" style={{resize:"vertical"}}/>
            </div>
            <div style={{display:"flex", gap:10, marginTop:4}}>
              <button type="submit" className="btn-primary" disabled={saving}>{saving?"Saving…":"Save Lead"}</button>
              <button type="button" className="btn-secondary" onClick={()=>setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* Filter tabs */}
      <div style={s.filterRow}>
        {["all",...STATUSES].map(f => (
          <button key={f} onClick={()=>setFilter(f)} style={{...s.filterBtn, ...(filter===f?s.filterActive:{})}}>
            {f} {f==="all" ? `(${leads.length})` : `(${leads.filter(l=>l.status===f).length})`}
          </button>
        ))}
      </div>

      {/* Leads table */}
      {loading ? <div style={{color:"#aaa", padding:20}}>Loading leads…</div> :
       filtered.length === 0 ? (
        <div style={s.emptyState}>
          <div style={{fontSize:40, marginBottom:12}}>👥</div>
          <div style={s.emptyTitle}>{filter==="all" ? "No leads yet" : `No ${filter} leads`}</div>
          <div style={s.emptySub}>Add your first lead to start tracking your pipeline</div>
        </div>
      ) : (
        <div className="card" style={{overflow:"hidden"}}>
          <table style={s.table}>
            <thead>
              <tr style={s.thead}>
                <th style={s.th}>Name</th>
                <th style={s.th}>Country</th>
                <th style={s.th}>Interest</th>
                <th style={s.th}>Budget</th>
                <th style={s.th}>Status</th>
                <th style={s.th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(l => (
                <tr key={l.id} style={s.tr}>
                  <td style={s.td}>
                    <div style={s.leadRow}>
                      <div style={s.avatar}>{l.name?.[0]?.toUpperCase()}</div>
                      <div>
                        <div style={s.leadName}>{l.name}</div>
                        <div style={s.leadSub}>{l.email || l.phone}</div>
                      </div>
                    </div>
                  </td>
                  <td style={s.td}>{l.country}</td>
                  <td style={s.td}>{l.interest || "—"}</td>
                  <td style={s.td}>{l.budget ? `${l.currency||"SGD"} ${l.budget}` : "—"}</td>
                  <td style={s.td}>
                    <select value={l.status||"new"} onChange={e=>updateStatus(l.id,e.target.value)}
                      style={{...s.statusSel, background:statusStyle[l.status]?.bg||"#f5f5f5", color:statusStyle[l.status]?.color||"#555"}}>
                      {STATUSES.map(st=><option key={st} value={st}>{st}</option>)}
                    </select>
                  </td>
                  <td style={s.td}>
                    <div style={{display:"flex", gap:6}}>
                      {l.phone && <a href={`https://wa.me/${l.phone.replace(/\D/g,"")}`} target="_blank" rel="noreferrer" style={s.waBtn}>💬 WA</a>}
                      <button onClick={()=>remove(l.id)} style={s.delBtn}>✕</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

const s = {
  topRow: { display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:28 },
  h1: { fontSize:24, fontWeight:700, color:"#111", marginBottom:4 },
  sub: { fontSize:13, color:"#888" },
  form: { padding:24, marginBottom:24 },
  formTitle: { fontFamily:"Space Grotesk", fontSize:16, fontWeight:700, marginBottom:20 },
  grid2: { display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:14 },
  field: { display:"flex", flexDirection:"column", gap:6 },
  label: { fontSize:12, fontWeight:600, color:"#555" },
  filterRow: { display:"flex", gap:6, marginBottom:18, flexWrap:"wrap" },
  filterBtn: { padding:"6px 14px", borderRadius:20, border:"1px solid #e0e0e0", background:"#fff", fontSize:12, fontWeight:600, color:"#888", cursor:"pointer" },
  filterActive: { background:"#111", color:"#fff", borderColor:"#111" },
  table: { width:"100%", borderCollapse:"collapse" },
  thead: { background:"#f9f9f9" },
  th: { padding:"12px 16px", fontSize:11, fontWeight:700, color:"#888", textAlign:"left", textTransform:"uppercase", letterSpacing:.5, borderBottom:"1px solid #e0e0e0" },
  tr: { borderBottom:"1px solid #f0f0f0" },
  td: { padding:"12px 16px", fontSize:13 },
  leadRow: { display:"flex", alignItems:"center", gap:10 },
  avatar: { width:30, height:30, borderRadius:"50%", background:"#111", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, fontWeight:700, flexShrink:0 },
  leadName: { fontSize:13, fontWeight:600, color:"#111" },
  leadSub: { fontSize:11, color:"#aaa" },
  statusSel: { border:"none", borderRadius:20, padding:"4px 10px", fontSize:11, fontWeight:700, cursor:"pointer", textTransform:"uppercase", letterSpacing:.5 },
  waBtn: { fontSize:11, fontWeight:600, background:"#f0f0f0", padding:"5px 10px", borderRadius:8, color:"#111" },
  delBtn: { fontSize:12, fontWeight:600, background:"none", border:"1px solid #e0e0e0", color:"#ccc", padding:"5px 10px", borderRadius:8, cursor:"pointer" },
  emptyState: { textAlign:"center", padding:"60px 20px" },
  emptyTitle: { fontFamily:"Space Grotesk", fontSize:18, fontWeight:700, color:"#111", marginBottom:8 },
  emptySub: { fontSize:13, color:"#888" }
};
