import React, { useState } from "react";
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../lib/firebase";

export default function Login() {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handle = async (e) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      if (mode === "login") await signInWithEmailAndPassword(auth, email, password);
      else await createUserWithEmailAndPassword(auth, email, password);
    } catch (err) {
      setError(err.message.replace("Firebase: ", "").replace(/\(auth.*\)\.?/, ""));
    }
    setLoading(false);
  };

  return (
    <div style={s.page}>
      <div style={s.left}>
        <div style={s.brand}>
          <div style={s.logoIcon}>AX</div>
          <div>
            <div style={s.logoText}>AgentX</div>
            <div style={s.tagline}>The Future of Real Estate in Asia</div>
          </div>
        </div>
        <div style={s.stats}>
          {[["24+", "Asian Markets"], ["10K+", "Agents"], ["$2B+", "Deals Closed"]].map(([v,l]) => (
            <div key={l} style={s.stat}>
              <div style={s.statVal}>{v}</div>
              <div style={s.statLabel}>{l}</div>
            </div>
          ))}
        </div>
        <div style={s.quote}>"AgentX saved me 4 hours a day on listing copy alone."<br/><span style={{color:"#888", fontSize:12}}>— Wei Chen, Senior Agent, Singapore</span></div>
      </div>

      <div style={s.right}>
        <div style={s.card}>
          <h2 style={s.cardTitle}>{mode === "login" ? "Welcome back" : "Create your account"}</h2>
          <p style={s.cardSub}>{mode === "login" ? "Sign in to your AgentX dashboard" : "Start your free AgentX account"}</p>

          <form onSubmit={handle} style={s.form}>
            <div style={s.field}>
              <label style={s.label}>Email</label>
              <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required />
            </div>
            <div style={s.field}>
              <label style={s.label}>Password</label>
              <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            {error && <div style={s.error}>{error}</div>}
            <button type="submit" className="btn-primary" style={{width:"100%", padding:"13px"}} disabled={loading}>
              {loading ? "Please wait…" : mode === "login" ? "Sign in →" : "Create account →"}
            </button>
          </form>

          <div style={s.toggle}>
            {mode === "login" ? "Don't have an account?" : "Already have an account?"}
            <button onClick={() => { setMode(mode==="login"?"signup":"login"); setError(""); }} style={s.toggleBtn}>
              {mode === "login" ? " Sign up" : " Sign in"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const s = {
  page: { display:"flex", minHeight:"100vh", background:"#fff" },
  left: { flex:1, background:"#111", padding:"60px 50px", display:"flex", flexDirection:"column", justifyContent:"center", gap:40 },
  brand: { display:"flex", alignItems:"center", gap:16 },
  logoIcon: { width:52, height:52, background:"#fff", borderRadius:14, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"Space Grotesk", fontWeight:800, fontSize:20, color:"#111", letterSpacing:-1 },
  logoText: { fontFamily:"Space Grotesk", fontWeight:800, fontSize:28, color:"#fff", letterSpacing:-1 },
  tagline: { fontSize:13, color:"#666", marginTop:2 },
  stats: { display:"flex", gap:32 },
  stat: {},
  statVal: { fontFamily:"Space Grotesk", fontWeight:800, fontSize:32, color:"#fff", letterSpacing:-1 },
  statLabel: { fontSize:12, color:"#666", marginTop:2 },
  quote: { fontSize:14, color:"#aaa", lineHeight:1.8, borderLeft:"2px solid #333", paddingLeft:16 },
  right: { flex:1, display:"flex", alignItems:"center", justifyContent:"center", padding:40 },
  card: { width:"100%", maxWidth:400 },
  cardTitle: { fontFamily:"Space Grotesk", fontSize:26, fontWeight:700, color:"#111", marginBottom:6 },
  cardSub: { fontSize:13, color:"#888", marginBottom:28 },
  form: { display:"flex", flexDirection:"column", gap:16 },
  field: { display:"flex", flexDirection:"column", gap:6 },
  label: { fontSize:12, fontWeight:600, color:"#555" },
  error: { background:"#fff5f5", border:"1px solid #fcc", borderRadius:8, padding:"10px 14px", fontSize:13, color:"#c00" },
  toggle: { marginTop:20, textAlign:"center", fontSize:13, color:"#888" },
  toggleBtn: { background:"none", border:"none", color:"#111", fontWeight:600, fontSize:13, cursor:"pointer", textDecoration:"underline" }
};
