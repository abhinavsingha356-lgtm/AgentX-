import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../lib/AuthContext";

const navItems = [
  { icon: "▦", label: "Dashboard", path: "/dashboard" },
  { icon: "🏠", label: "Listings", path: "/listings" },
  { icon: "👥", label: "Leads", path: "/leads" },
  { icon: "🤖", label: "AI Assistant", path: "/ai" },
  { icon: "📊", label: "Analytics", path: "/analytics" },
  { icon: "💰", label: "Commissions", path: "/commissions" },
];

export default function Layout({ children }) {
  const { profile, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  async function handleLogout() {
    await logout();
    navigate("/");
  }

  const s = styles;
  const initials = profile?.name?.split(" ").map(n => n[0]).join("").slice(0,2).toUpperCase() || "AX";

  return (
    <div style={s.shell}>
      {/* Mobile header */}
      <div style={s.mobileHeader}>
        <div style={s.mobileLogo}>
          <div style={s.logoIcon}>AX</div>
          <span style={s.logoText}>Agent<span style={{color:"#555"}}>X</span></span>
        </div>
        <button style={s.hamburger} onClick={() => setMobileOpen(!mobileOpen)}>☰</button>
      </div>

      {/* Sidebar */}
      <aside style={{...s.sidebar, ...(mobileOpen ? s.sidebarOpen : {})}}>
        <div style={s.logo}>
          <div style={s.logoIcon}>AX</div>
          <span style={s.logoText}>Agent<span style={{color:"#555"}}>X</span></span>
        </div>

        <nav style={s.nav}>
          <div style={s.navLabel}>Main</div>
          {navItems.map(item => (
            <div key={item.path}
              style={{...s.navItem, ...(location.pathname === item.path ? s.navActive : {})}}
              onClick={() => { navigate(item.path); setMobileOpen(false); }}>
              <span style={s.navIcon}>{item.icon}</span>
              {item.label}
            </div>
          ))}
          <div style={s.navLabel}>Account</div>
          <div style={{...s.navItem, ...(location.pathname === "/profile" ? s.navActive : {})}}
            onClick={() => { navigate("/profile"); setMobileOpen(false); }}>
            <span style={s.navIcon}>👤</span> Profile
          </div>
          <div style={{...s.navItem, ...(location.pathname === "/settings" ? s.navActive : {})}}
            onClick={() => { navigate("/settings"); setMobileOpen(false); }}>
            <span style={s.navIcon}>⚙️</span> Settings
          </div>
        </nav>

        <div style={s.sidebarFooter}>
          <div style={s.agentChip}>
            <div style={s.avatar}>{initials}</div>
            <div style={s.agentInfo}>
              <div style={s.agentName}>{profile?.name || "Agent"}</div>
              <div style={s.agentPlan}>🇸🇬 {profile?.country || "Asia"}</div>
            </div>
            <button style={s.logoutBtn} onClick={handleLogout} title="Sign out">↩</button>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {mobileOpen && <div style={s.overlay} onClick={() => setMobileOpen(false)} />}

      {/* Main content */}
      <main style={s.main}>{children}</main>
    </div>
  );
}

const styles = {
  shell: { display: "flex", minHeight: "100vh", background: "#F7F7F8" },
  sidebar: {
    width: 220, minHeight: "100vh",
    background: "#fff", borderRight: "1px solid #E8E8E8",
    display: "flex", flexDirection: "column",
    padding: "24px 0", flexShrink: 0,
    position: "sticky", top: 0, height: "100vh",
    zIndex: 100,
    "@media (max-width: 768px)": { display: "none" }
  },
  sidebarOpen: {
    position: "fixed", left: 0, top: 0, height: "100vh",
    zIndex: 200, boxShadow: "4px 0 20px rgba(0,0,0,0.1)"
  },
  logo: {
    display: "flex", alignItems: "center", gap: 10,
    padding: "0 20px 24px", borderBottom: "1px solid #F0F0F0"
  },
  logoIcon: {
    width: 32, height: 32, borderRadius: 8, background: "#111",
    color: "#fff", display: "flex", alignItems: "center", justifyContent: "center",
    fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 14
  },
  logoText: { fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 18, color: "#111" },
  nav: { padding: "20px 12px", flex: 1 },
  navLabel: {
    fontSize: 10, fontWeight: 700, letterSpacing: "1.2px",
    color: "#BBB", textTransform: "uppercase",
    padding: "0 8px", marginBottom: 6, marginTop: 18
  },
  navItem: {
    display: "flex", alignItems: "center", gap: 10,
    padding: "9px 12px", borderRadius: 8,
    color: "#888", cursor: "pointer",
    fontSize: 13.5, fontWeight: 500, marginBottom: 2,
    transition: "all 0.15s"
  },
  navActive: { background: "#F5F5F5", color: "#111", fontWeight: 600 },
  navIcon: { fontSize: 15, width: 18, textAlign: "center" },
  sidebarFooter: { padding: "16px 16px", borderTop: "1px solid #F0F0F0" },
  agentChip: { display: "flex", alignItems: "center", gap: 10 },
  avatar: {
    width: 32, height: 32, borderRadius: "50%",
    background: "#111", color: "#fff",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontWeight: 700, fontSize: 12, flexShrink: 0
  },
  agentInfo: { flex: 1, overflow: "hidden" },
  agentName: { fontSize: 13, fontWeight: 600, color: "#111", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  agentPlan: { fontSize: 11, color: "#888" },
  logoutBtn: {
    background: "none", border: "none", color: "#BBB",
    fontSize: 16, cursor: "pointer", padding: 4,
    borderRadius: 6, transition: "color 0.15s"
  },
  // Mobile
  mobileHeader: {
    display: "none",
    "@media (max-width: 768px)": {
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "14px 20px", background: "#fff",
      borderBottom: "1px solid #E8E8E8",
      position: "sticky", top: 0, zIndex: 150
    }
  },
  mobileLogo: { display: "flex", alignItems: "center", gap: 8 },
  hamburger: {
    background: "none", border: "none",
    fontSize: 20, cursor: "pointer", color: "#111"
  },
  overlay: {
    position: "fixed", inset: 0,
    background: "rgba(0,0,0,0.3)", zIndex: 199
  },
  main: { flex: 1, overflow: "auto", minHeight: "100vh" }
};
