import React, { useState } from "react";
import { Outlet, NavLink, useNavigate } from "react-router-dom";
import { signOut } from "firebase/auth";
import { auth } from "../lib/firebase";

const nav = [
  { to: "/",          icon: "▦",  label: "Dashboard" },
  { to: "/listings",  icon: "🏠", label: "Listings"  },
  { to: "/leads",     icon: "👥", label: "Leads"     },
  { to: "/ai",        icon: "🤖", label: "AI"        },
];

export default function Layout({ user }) {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut(auth);
    navigate("/login");
  };

  const initials = user.email ? user.email[0].toUpperCase() : "A";

  return (
    <div style={styles.root}>
      {/* SIDEBAR */}
      <aside style={styles.sidebar}>
        <div style={styles.logo}>
          <div style={styles.logoIcon}>AX</div>
          <span style={styles.logoText}>Agent<span style={{color:"#555"}}>X</span></span>
        </div>

        <nav style={styles.nav}>
          <div style={styles.navLabel}>MAIN</div>
          {nav.map(n => (
            <NavLink key={n.to} to={n.to} end={n.to==="/"} style={({isActive}) => ({
              ...styles.navItem,
              ...(isActive ? styles.navItemActive : {})
            })}>
              <span style={{fontSize:16}}>{n.icon}</span> {n.label}
            </NavLink>
          ))}
        </nav>

        <div style={styles.sidebarFooter}>
          <div style={styles.avatar}>{initials}</div>
          <div style={{flex:1, overflow:"hidden"}}>
            <div style={{fontSize:12, fontWeight:600, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}}>{user.email}</div>
            <div style={{fontSize:11, color:"#888"}}>Pro Agent</div>
          </div>
          <button onClick={handleSignOut} style={styles.signOutBtn} title="Sign out">↩</button>
        </div>
      </aside>

      {/* MAIN */}
      <main style={styles.main}>
        {/* Mobile topbar */}
        <div style={styles.mobileBar}>
          <div style={{fontFamily:"Space Grotesk", fontWeight:700, fontSize:18}}>Agent<span style={{color:"#555"}}>X</span></div>
          <button onClick={() => setMobileOpen(!mobileOpen)} style={styles.hamburger}>☰</button>
        </div>

        {/* Mobile nav dropdown */}
        {mobileOpen && (
          <div style={styles.mobileNav}>
            {nav.map(n => (
              <NavLink key={n.to} to={n.to} end={n.to==="/"} onClick={() => setMobileOpen(false)}
                style={({isActive}) => ({...styles.mobileNavItem, ...(isActive ? styles.navItemActive : {})})}>
                {n.icon} {n.label}
              </NavLink>
            ))}
          </div>
        )}

        <div style={styles.content}>
          <Outlet />
        </div>
      </main>
    </div>
  );
}

const styles = {
  root: { display:"flex", minHeight:"100vh", background:"#f5f5f7" },
  sidebar: {
    width: 220, background:"#fff", borderRight:"1px solid #e0e0e0",
    display:"flex", flexDirection:"column", padding:"24px 0",
    position:"sticky", top:0, height:"100vh", flexShrink:0,
    "@media(max-width:768px)": { display:"none" }
  },
  logo: { display:"flex", alignItems:"center", gap:10, padding:"0 20px 24px", borderBottom:"1px solid #e0e0e0" },
  logoIcon: { width:34, height:34, background:"#111", borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", color:"#fff", fontFamily:"Space Grotesk", fontWeight:800, fontSize:14, letterSpacing:-1 },
  logoText: { fontFamily:"Space Grotesk", fontWeight:700, fontSize:18, color:"#111" },
  nav: { padding:"16px 12px", flex:1 },
  navLabel: { fontSize:10, fontWeight:700, letterSpacing:1.2, color:"#bbb", padding:"0 8px", marginBottom:8, marginTop:8 },
  navItem: { display:"flex", alignItems:"center", gap:10, padding:"9px 12px", borderRadius:8, color:"#888", fontSize:13.5, fontWeight:500, marginBottom:2, transition:"all .15s" },
  navItemActive: { background:"#f0f0f0", color:"#111", fontWeight:600 },
  sidebarFooter: { padding:"16px 20px", borderTop:"1px solid #e0e0e0", display:"flex", alignItems:"center", gap:10 },
  avatar: { width:34, height:34, borderRadius:"50%", background:"#111", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700, fontSize:13, flexShrink:0 },
  signOutBtn: { background:"none", border:"none", color:"#aaa", fontSize:16, padding:4, cursor:"pointer" },
  main: { flex:1, display:"flex", flexDirection:"column", minWidth:0 },
  mobileBar: { display:"none", alignItems:"center", justifyContent:"space-between", padding:"14px 20px", background:"#fff", borderBottom:"1px solid #e0e0e0", "@media(max-width:768px)": { display:"flex" } },
  hamburger: { background:"none", border:"none", fontSize:20, cursor:"pointer" },
  mobileNav: { background:"#fff", borderBottom:"1px solid #e0e0e0", padding:"8px 16px", display:"flex", flexDirection:"column", gap:4 },
  mobileNavItem: { display:"flex", alignItems:"center", gap:10, padding:"10px 12px", borderRadius:8, color:"#888", fontSize:14, fontWeight:500 },
  content: { flex:1, padding:"32px 28px", maxWidth:1100, width:"100%", margin:"0 auto" }
};
