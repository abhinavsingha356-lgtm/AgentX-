# AgentX 🏠

AI-powered real estate platform for Asian agents.

## Setup in 4 steps

### 1. Firebase
1. Go to https://console.firebase.google.com
2. Click "Add project" → name it "agentx"
3. Go to Build → Authentication → Get Started → Enable Email/Password
4. Go to Build → Firestore Database → Create database → Start in test mode
5. Go to Project Settings (⚙️) → Your apps → Web → Register app
6. Copy the config values into `src/lib/firebase.js`

### 2. Claude API Key
1. Go to https://console.anthropic.com
2. Sign up free → API Keys → Create Key
3. Copy the key (starts with sk-ant-...)
4. Paste it inside the AI Assistant page in the app

### 3. Deploy to Vercel
1. Push this folder to your GitHub repo
2. Go to https://vercel.com → Import your repo
3. Click Deploy — done! Live in 60 seconds.

### 4. Install on phone (PWA)
- Open your Vercel URL on your phone
- Tap Share → "Add to Home Screen"
- AgentX is now an app on your phone!

## Features
- ✅ Agent login & signup
- ✅ Dashboard with live stats
- ✅ Property listings (add, view, delete)
- ✅ Leads CRM (pipeline, WhatsApp link, status tracking)
- ✅ AI Assistant (listings, emails, translation, negotiation tips)
- ✅ Multi-currency (SGD, MYR, IDR, THB, PHP, INR)
- ✅ PWA — installs on iOS & Android
- ✅ Multi-language AI responses

## Tech Stack
- React 18
- Firebase (Auth + Firestore)
- Claude API (Anthropic)
- Vercel (hosting)
- PWA (mobile)

Built with ❤️ by AgentX
